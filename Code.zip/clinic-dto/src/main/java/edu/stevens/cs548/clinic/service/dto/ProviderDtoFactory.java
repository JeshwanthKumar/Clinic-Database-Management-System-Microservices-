package edu.stevens.cs548.clinic.service.dto;


public class ProviderDtoFactory {
	
	
	public ProviderDtoFactory() {
	}
	
	public ProviderDto createProviderDto () {
		return new ProviderDto();
	}
	
}
